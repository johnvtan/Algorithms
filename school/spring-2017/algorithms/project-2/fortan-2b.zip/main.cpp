// Mary Forde, John Tan
// Project 2

// Starts a game of playFlip.

#include"playFlip.h"

using namespace std;

int main()
// starts a game of playFlip
{
	playFlip();
        
	return 0;
}


