// Mary Forde, John Tan
// Project 2

//Declaration of the PlayFlip global function, which plays a game of 'playflip'

void playFlip();
